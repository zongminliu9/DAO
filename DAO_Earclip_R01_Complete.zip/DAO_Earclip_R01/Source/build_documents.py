from pathlib import Path
import json,math,textwrap
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor,Color,white
from reportlab.lib.pagesizes import A4,A3,landscape
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import Paragraph,Table,TableStyle
from reportlab.lib.styles import ParagraphStyle
ROOT=Path(__file__).resolve().parents[1]; SCRATCH=ROOT.parent
font_path=ROOT/'Source/fonts/NotoSansSC-Regular.ttf'
pdfmetrics.registerFont(TTFont('CN',str(font_path)))
pdfmetrics.registerFont(TTFont('Latin',str(ROOT/'Source/fonts/NotoSans-Regular.ttf')))
pdfmetrics.registerFont(TTFont('LatinBold',str(ROOT/'Source/fonts/NotoSans-Bold.ttf')))
INK=HexColor('#183b37');GRAY=HexColor('#52645f');GOLD=HexColor('#b09a61');PAPER=HexColor('#f4f3ed');LINE=HexColor('#d6dcd4')
W,H=landscape(A3)
c=canvas.Canvas(str(ROOT/'Drawings/DAO_R01_CAD_Review.pdf'),pagesize=(W,H));c.setTitle('DAO R01 | Earclip CAD concept review')
def txt(x,y,s,size=10,font='Helvetica',color=INK):
 font={'Helvetica':'Latin','Helvetica-Bold':'LatinBold'}.get(font,font)
 c.setFillColor(color);c.setFont(font,size);c.drawString(x,y,s)
def line(x1,y1,x2,y2,color=GRAY,width=.7):
 c.setStrokeColor(color);c.setLineWidth(width);c.line(x1,y1,x2,y2)
def head(n,title,sub):
 c.setFillColor(white);c.rect(0,0,W,H,fill=1,stroke=0)
 txt(38,H-45,'DAO / LIGHT, IN CONTEXT',11,'Helvetica-Bold');txt(38,H-82,title,27,'Helvetica-Bold');txt(38,H-105,sub,10)
 line(38,70,W-38,70);txt(38,51,'DAO-EC-R01   |   CONCEPT FOR INVESTOR / INCUBATOR REVIEW   |   NOT FOR MANUFACTURE',9,'Helvetica-Bold')
 txt(38,33,'Units: mm  |  Revision: R01  |  2026-09-27  |  Dimensions are nominal design values unless identified as vendor data.',8)
 txt(W-110,40,f'{n:02d} / 05',11,'Helvetica-Bold')
def img(name,x,y,w,h):c.drawImage(str(ROOT/'Preview'/name),x,y,w,h,mask='auto',preserveAspectRatio=True,anchor='c')
def para(x,y,text,width,size=10,leading=15,font='Helvetica',color=INK):
 font={'Helvetica':'Latin','Helvetica-Bold':'LatinBold'}.get(font,font)
 st=ParagraphStyle('x',fontName=font,fontSize=size,leading=leading,textColor=color)
 p=Paragraph(text,st);pw,ph=p.wrap(width,800);p.drawOn(c,x,y-ph);return y-ph

def dimh(x1,x2,y,label):
 line(x1,y,x2,y);line(x1,y-5,x1,y+5);line(x2,y-5,x2,y+5)
 for x,sg in [(x1,1),(x2,-1)]:line(x,y,x+sg*5,y+2);line(x,y,x+sg*5,y-2)
 c.setFillColor(white);c.rect((x1+x2)/2-25,y-5,50,14,fill=1,stroke=0);txt((x1+x2)/2-20,y-2,label,9)
def dimv(x,y1,y2,label):
 line(x,y1,x,y2);line(x-5,y1,x+5,y1);line(x-5,y2,x+5,y2)
 for y,sg in [(y1,1),(y2,-1)]:line(x,y,x+2,y+sg*5);line(x,y,x-2,y+sg*5)
 txt(x+8,(y1+y2)/2,label,9)
# 1
head(1,'An optical instrument, worn as an earclip','Non-piercing R01 package study. A real solid model with simplified component envelopes; no finished electronics or clinical claims.')
img('DAO_R01_Assembly.png',35,160,540,540);img('DAO_R01_Internal.png',595,160,540,540)
txt(60,675,'ASSEMBLED / OUTWARD OPTICAL FACE',11,'Helvetica-Bold');txt(615,675,'CAP REMOVED / PACKAGING STUDY',11,'Helvetica-Bold')
for x,a,b in [(60,'26 x 16 x 10.4','Electronic pod envelope'),(325,'5.0 mm','Unloaded pad-to-pad gap'),(615,'25 solids','STEP assembly / individually named'),(885,'BLE -> phone -> Hue','Room-light feedback architecture')]:
 txt(x,140,a,18,'Helvetica-Bold');txt(x,121,b,10)
para(60,104,'Optical face orientation must be indexed and tested on-ear. The model does not establish eye-level equivalence or fit across ear anatomies.',1040,9,12)
c.showPage()
# 2
head(2,'Exploded assembly','Part numbers link to individual STEP files and the BOM. Spacing is expanded for clarity, not an assembly motion simulation.')
img('DAO_R01_Exploded.png',35,86,680,650)
rows=[('04 / 05','DIFFUSER + BOND','5.0 diameter x 0.5 diffuser; 0.1 radial adhesive allowance.'),('02','FRONT CAP','Nonconductive shell. Keep the upper crown free of metallic paint.'),('03 / 06','SEAM + OPTICAL BAFFLE','0.1 bond line; black light well limits internal stray light.'),('07-17','PCB + COMPONENT ALLOCATIONS','13.4 x 23.4 x 0.6 PCB. Packages, antenna and passives are simplified.'),('18 / 19','CELL ENVELOPE + INSULATION','12.4 diameter x 5.7 allocation; nominal cell is 12.1 x 5.4.'),('01 / 24','REAR TUB + WEAR ELECTRODE','Support ledges, charge feedthrough bores and electrode allowance.'),('20-23','CLIP, PADS + CONTACTS','Replaceable comfort pads; clamp force and seals remain to be engineered.')]
y=690
for no,title,body in rows:
 txt(735,y,no,11,'Helvetica-Bold',GOLD);txt(800,y,title,11,'Helvetica-Bold');para(800,y-12,body,310,10,14);y-=80
c.showPage()
# 3
head(3,'Envelope and interface dimensions','Orthographic layout / independent labeled views. Nominal scale 5:1 at A3 print size; do not scale the document.')
s=5*72/25.4
# front
ox,oy=235,400
c.setStrokeColor(INK);c.setLineWidth(1);c.roundRect(ox-8*s,oy-13*s,16*s,26*s,4*s,fill=0,stroke=1)
c.circle(ox,oy+3*s,2.5*s,fill=0,stroke=1)
line(ox-9*s,oy+3*s,ox+9*s,oy+3*s,LINE);line(ox,oy-14*s,ox,oy+14*s,LINE)
txt(115,625,'FRONT / OPTICAL FACE',12,'Helvetica-Bold')
dimh(ox-8*s,ox+8*s,oy-15*s,'16.0');dimv(ox-10*s,oy-13*s,oy+13*s,'26.0')
line(ox+2.5*s,oy+3*s,ox+6*s,oy+7*s);txt(ox+3*s,oy+8*s,'DIA 5.0 window',9)
txt(110,162,'R4 external corners | Window center: X0, Y+3.0',9)
# side true profile sampled around annulus, y on vertical, z horizontal
sx,sy=655,400
# shell
c.rect(sx,sy-13*s,10.4*s,26*s,stroke=1,fill=0);line(sx+8.8*s,sy-13*s,sx+8.8*s,sy+13*s,GRAY)
# clip section path from model union ring/stems, exact nominal profile
pts=[]
# profile front top y=-6 z=0 down to curve front outer at y=-11 z0
pts=[(-6,0),(-11,0)]
for a in range(90,271,3):pts.append((-11+3.65*math.cos(math.radians(a)),-3.65+3.65*math.sin(math.radians(a))))
pts += [(3,-7.3),(3,-6.8),(-11,-6.8)]
for a in range(270,89,-3):pts.append((-11+3.15*math.cos(math.radians(a)),-3.65+3.15*math.sin(math.radians(a))))
pts +=[(-6,-.5)]
p=c.beginPath();p.moveTo(sx+pts[0][1]*s,sy+pts[0][0]*s)
for y,z in pts[1:]:p.lineTo(sx+z*s,sy+y*s)
p.close();c.drawPath(p,stroke=1,fill=0)
c.rect(sx-.8*s,sy-2*s,.8*s,8*s,stroke=1,fill=0);c.rect(sx-6.8*s,sy-5*s,1*s,8*s,stroke=1,fill=0)
txt(560,625,'SIDE / CLAMP SECTION',12,'Helvetica-Bold')
dimh(sx,sx+10.4*s,oy+15*s,'10.4');dimh(sx-7.3*s,sx+10.4*s,oy-17*s,'17.7 overall')
dimh(sx-5.8*s,sx-.8*s,oy+7*s,'5.0 gap')
txt(525,125,'Clip sheet: 0.5 nominal | Overall height including bend: 27.65',9)
# rear compact interface
rx,ry=1020,400;rs=9
c.roundRect(rx-8*rs,ry-13*rs,16*rs,26*rs,4*rs,stroke=1,fill=0)
c.setDash(3,3);c.roundRect(rx-3.5*rs,ry-2*rs,7*rs,8*rs,2*rs,stroke=1,fill=0);c.setDash()
for x in [-3,3]:c.circle(rx+x*rs,ry-9.5*rs,.7*rs,stroke=1,fill=0)
txt(935,625,'REAR INTERFACES',12,'Helvetica-Bold');txt(935,605,'Enlarged detail / NTS',9)
dimh(rx-3*rs,rx+3*rs,ry-14.5*rs,'6.0 pitch')
para(932,225,'Charge contacts: DIA 1.4<br/>Bores: DIA 1.7<br/>Centers: X +/-3.0, Y -9.5<br/>Sealed feedthroughs TBD<br/>Dashed: front skin pad',195,10,16)
c.showPage()
# 4
head(4,'Optical stack and board allocations','Section and component layout from R01 parameters. Aperture alignment, spectral response and RF behavior must be validated on hardware.')
# section magnified 22 pt/mm, z horizontal y vertical
ox,oy,ss=110,388,18
# model X0 sliced geometry schematic faithful rectangles + battery round chord at X0
def rectz(z,y,d,h,fill):
 c.setFillColor(HexColor(fill));c.setStrokeColor(INK);c.setLineWidth(.45);c.rect(ox+z*ss,oy+y*ss,d*ss,h*ss,stroke=1,fill=1)
rectz(0,-13,.8,26,'#cbb681')
rectz(.8,-13,8,.8,'#cbb681');rectz(.8,12.2,8,.8,'#cbb681')
rectz(9.6,-13,.8,13.4,'#e1d4b5');rectz(9.6,5.6,.8,7.4,'#e1d4b5')
rectz(1,-10.2,5.7,12.4,'#a2b7bc');rectz(6.9,-11.7,.6,23.4,'#286353')
rectz(7.5,2,1,2,'#283e41');rectz(9.9,.5,.5,5,'#b6d9d5')
for y in [.45,5.2]:rectz(7.9,y,1.6,.35,'#293b39')
txt(65,680,'A-A / X = 0 / NTS',12,'Helvetica-Bold')
# Section dimensions are nominal concept values.
# labels placed right
for y,text in [(640,'Z10.4 outer face'),(604,'Z9.9 diffuser inside face'),(568,'Z8.5 sensor top'),(532,'Z7.5 PCB component side'),(496,'Z6.9 PCB underside'),(460,'Z6.7 cell envelope top'),(424,'Z1.0 cell envelope bottom'),(388,'Z0.8 housing inner floor')]:txt(395,y,text,9)
para(395,345,'The optical path is a prototype allowance, not a ray-traced design. Diffuser selection and baffle geometry must be tested together. Sensor-to-diffuser spacing: 1.4 mm nominal.',205,10,15)
# PCB x/y layout at scale 16
px,py,ps=870,390,16
c.setFillColor(HexColor('#edf3ed'));c.setStrokeColor(INK);c.roundRect(px-6.7*ps,py-11.7*ps,13.4*ps,23.4*ps,2.3*ps,fill=1,stroke=1)
manifest=json.loads((ROOT/'Engineering/parts_manifest.json').read_text())
placements=[('08',0,3,3.1,2),('09',0,-2.2,3,3.3),('10',-3.2,-7,2.5,2.5),('11',3.1,-7,2,2),('12',-4,0,2.5,3),('13',4,0,2.5,3),('14',0,-9.7,4,1.5),('15',-3,6.3,3.5,1.5),('16',3.5,5.8,2.5,2),('17',0,9.3,10,3.2)]
for no,x,y,w,h in placements:
 c.setFillColor(HexColor('#d9c590') if no=='17' else HexColor('#48786a'));c.rect(px+(x-w/2)*ps,py+(y-h/2)*ps,w*ps,h*ps,stroke=1,fill=1);txt(px+x*ps-6,py+y*ps-3,no,9,'Helvetica-Bold',white if no!='17' else INK)
txt(720,680,'PCB TOP / PLACEMENT ENVELOPES',12,'Helvetica-Bold');dimh(px-6.7*ps,px+6.7*ps,py-14*ps,'13.4');dimv(px+8*ps,py-11.7*ps,py+11.7*ps,'23.4')
para(720,142,'17 = antenna allocation; no metal coating above it. 12-16 = unselected flash, wear frontend, protection, matching and crystal. Not a Gerber, schematic or layout approval.',380,9,12)
c.showPage()
# 5
head(5,'Build decisions and release boundary','What this model resolves, and what an engineering team must close before a functional wearable or production tooling.')
cols=[(48,340,'MECHANICAL / OPTICAL'),(432,330,'ELECTRONICS / CONTROL'),(800,340,'VERIFICATION / DELIVERABLES')]
texts=[[
'Non-piercing, lower-ear clip. The bend wraps below the ear edge; two soft pads spread the load. A single size is not an approved fit.',
'Nonconductive polymer shells preserve the antenna zone. Metallic jewellery finishes require a separate RF evaluation; gold color here is a nonmetallic pigment concept.',
'Flush achromatic diffuser with a black light well. Do not cover with an uncharacterized tinted decorative lens.',
'Adhesive seam shown. Glue process, datum scheme, sealing, edge radii, draft, serviceability and retention remain design tasks.',
'Charge only off-ear in a keyed dock. Dock geometry is not included; interface coordinates are on sheet 03.'
],[
'AS7341 candidate for the first optical prototype; evaluate AS7343 if testing shows a meaningful accuracy advantage. No calibrated mEDI output is native to the CAD.',
'1.8 V logic rail; BLE SoC, I2C sensors, charger, protected cell, NTC, decoupling and RF matching must be designed as a complete circuit.',
'Phone receives BLE data. Local Hue Bridge controls a compatible lamp via its supported API; the earclip does not speak Wi-Fi directly to the lamp.',
'Close the lighting loop only with valid wear state, fresh readings and an authorized room. Rate-limit lamp changes and preserve manual override.',
'Photopic lux and estimated melanopic EDI are distinct. No direct hormone, UV dose, circadian phase or focus measurement.'
],[
'CAD checks: 25 valid solids; no nominal positive-volume interference; STEP exported and re-imported. These checks do not verify real-world functionality.',
'Files: named assembly STEP, exploded STEP, individual STEP parts, selected mechanical STL files, 2D DXF, BOM and editable Python source.',
'Next gate: optical bench calibration, on-ear versus eye-reference comparisons, clamp comfort, RF on-body tests and measured power budget.',
'After that: PCB layout, working firmware, dock, enclosure tolerances and pilot builds. Battery, radio and skin-contact compliance are unresolved.',
'Use these drawings in an application as a proposed engineering concept. Do not present them as a built prototype, tested product or factory release.'
]]
for (x,w,t),blocks in zip(cols,texts):
 txt(x,675,t,13,'Helvetica-Bold');y=645
 for i,b in enumerate(blocks):
  txt(x,y,f'{i+1:02d}',11,'Helvetica-Bold',GOLD);y=para(x+32,y+2,b,w-32,11,17)-26
c.save()
# Chinese brief A4; use fixed pages for deliberate reading order.
c=canvas.Canvas(str(ROOT/'DAO_R01_Design_Brief_CN.pdf'),pagesize=A4);W,H=A4;c.setTitle('DAO 光感耳夹 R01 — 投资申请与工程说明')
CN=ParagraphStyle('CN',fontName='CN',fontSize=10.3,leading=17,textColor=INK,wordWrap='CJK')
def chhead(n,title,kicker='DAO EARCLIP / R01'):
 c.setFillColor(PAPER);c.rect(0,0,W,H,stroke=0,fill=1);txt(42,H-40,kicker,10,'Helvetica-Bold');txt(42,H-78,title,21,'CN');line(42,49,W-42,49);txt(42,32,'R01 / 投资与孵化器申请概念稿 / 非量产工程释放',8,'CN');txt(W-72,32,f'{n:02d}',9,'Helvetica-Bold')
def cp(y,t,size=10.3):return para(42,y,t,W-84,size,size*1.65,'CN')-12
def sh(y,t):txt(42,y-3,t,13,'CN');return y-27
def table(y,rows,widths):
 ps=ParagraphStyle('tab',fontName='CN',fontSize=9,leading=14,textColor=INK,wordWrap='CJK')
 ts=[[Paragraph(str(z),ps) for z in r] for r in rows]
 tb=Table(ts,colWidths=widths);tb.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),HexColor('#dfe8df')),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),8),('RIGHTPADDING',(0,0),(-1,-1),8),('TOPPADDING',(0,0),(-1,-1),8),('BOTTOMPADDING',(0,0),(-1,-1),8),('LINEBELOW',(0,0),(-1,-1),.4,LINE)]));tw,th=tb.wrap(W-84,700);tb.drawOn(c,42,y-th);return y-th-20
chhead(1,'把光照记录变成环境反馈')
y=cp(735,'本套按“投资／孵化器申请”制作：提出一个能解释结构、器件空间和控制逻辑的无耳洞光感耳夹。模型是真实三维实体 CAD；芯片、电池与天线表示封装或空间预留。尚未做出可工作的电路、固件或实物。')
c.drawImage(str(ROOT/'Preview/DAO_R01_Assembly.png'),130,315,335,335,mask='auto')
y=sh(312,'申请材料可以这样描述')
y=cp(y,'DAO 正在开发首饰形态的光照感知设备，记录佩戴位置的光照强度与光谱信息，并通过手机连接兼容智能灯，在用户授权的房间内调整照明，再利用新的测量反馈修正设置。首轮原型将验证测量准确性、佩戴接受度与照明控制效果。')
y=table(y,[['交付','内容'],['CAD 包','装配 STEP、爆炸 STEP、25 个零件 STEP、部分结构 STL、尺寸 DXF'],['阅读材料','5 页英文 CAD 审阅图＋本中文研究说明；含来源、边界和验证计划']],[88,423])
c.showPage()
chhead(2,'三种功能，应该怎样落地')
y=table(735,[['你的场景','V1 可做的功能','应避免的表述'],['室内光线不足','测量＋分时段目标＋兼容灯调亮／调暗／调色温；回测效果','“白天欠了多少光，晚上自动补回来”'],['电脑视觉疲劳','工作照明舒适度场景、屏幕周边补光、休息提醒与用户主观评分','“消除蓝光伤害”或“测出眼疲劳”'],['专注工作','用户选择的工作照明预设；记录任务表现与舒适度验证','“自动提高专注力 X%”'],['旅行／时差','按行程、作息与暴露记录提供动态计划；先验证依从性','“直接测出昼夜节律相位”或“确保无时差”']],[95,210,206])
y=cp(y,'光的时间、强度、光谱和持续时间需要共同考虑。相同的光照量在不同时间不一定产生相同效果，因此不能把日间不足作为傍晚补强光的理由。[S7、S10]')
y=cp(y,'“电脑蓝光导致疲劳，所以调灯就能治疗”这一推理缺乏依据。Cochrane 对蓝光过滤镜片的系统评价并未支持其短期缓解电脑视疲劳的效果；该研究不是 DAO 灯光方案的疗效试验，因此也不能反过来证明 DAO 有效。[S8]')
y=sh(y,'优先演示哪个闭环？')
y=cp(y,'先做固定办公位：授权一盏 Hue 灯，耳夹记录光照，调灯，回测，再判断是否进入目标区间。它比机场／酒店更可控。旅行仍可作为需求场景，但在不能控制灯光的地方，产品只能记录与建议，不能声称自动控制环境。')
c.showPage()
chhead(3,'推荐结构与器件选择')
y=table(735,[['模块','R01 选择／尺寸','设计理由与待决项'],['光谱传感器','AS7341：3.1 × 2.0 × 1.0 mm [S1]','适合先做原型；AS7343 为对照候选 [S11]；须实测多种光源'],['BLE 主控','nRF52832 WLCSP：约 3.0 × 3.2 mm [S2]','R01 空间方案；采购时核实具体可供订货号与生命周期'],['电源管理','BQ25120A：2.5 × 2.5 mm [S3]','充电＋稳压；还需保护、热敏电阻及外围器件'],['动作传感器','LIS2DW12：2 × 2 × 0.7 mm [S4]','低功耗动作／倾斜；不能测眼睛注视方向'],['电池','CP1254 A4X：12.1 × 5.4 mm、74 mAh [S5]','模型预留直径 12.4 × 高 5.7；焊片／引线仍需核对'],['佩戴识别','电容电极＋动作联合判断','单凭黑暗无法区分摘下、头发遮挡或夜间；前端料号未选'],['外壳与夹持','非导电聚合物＋钛片候选＋软垫','射频区不做金属包覆；接触材料与夹力必须测试']],[92,190,229])
y=cp(y,'第一版不装治疗光源、心率 PPG 或 UV 传感器。它们会增加体积、功耗与验证任务，却不解决室内照明反馈的核心问题。AS7341 不能被当作已经校准的 UVA／UVB 剂量计。')
y=cp(y,'金色外观在本方案中表示非金属颜料效果，不代表整件金属外壳。若改成连续镀金层，天线性能及光学窗口需重新设计。')
c.showPage()
chhead(4,'光学：不是把芯片藏进耳环就够了')
y=sh(735,'入光面 → 扩散片 → 遮光腔 → 光谱传感器')
y=cp(y,'R01 使用直径 5 mm 的扩散窗口、黑色光阱与独立传感器腔。AS7341 原厂要求在入光口上方配置无色差扩散片。[S1] 扩散片材料、厚度与表面处理不能仅凭外观决定；外壳、扩散片和传感器必须作为整机校准。')
y=cp(y,'输出分两层：① 经标定的佩戴位置 photopic lux；② 使用多通道响应拟合 CIE melanopic EDI 的估计值，单位同为 lx，但代表不同加权。通道计数不是现成 mEDI；拟合系数须由参考光谱仪及独立验证光源获得。[S7]')
y=sh(y,'耳位不是眼位，方向比“离眼睛近”更关键')
y=cp(y,'研究指出，传感器位置平移、旋转和身体遮挡都会造成偏差。[S6] 普通耳垂夹可能朝向侧面；本模型的 Z 轴只是光学法线，尚未把它证明为视线方向。须在耳模和真人上固定安装方向，比较前向、侧向、头发覆盖与眼镜共存时的读数。')
y=cp(y,'佩戴状态与置信度必须进入算法。加速度计能识别部分运动／倾斜，但不能独立识别偏航角、注视方向或所有遮挡。佩戴不确定、传感器饱和或遮挡时，暂停自动调灯并提示检查，不能把暗读数直接解释为“缺光”。')
y=table(y,[['原型测试','建议验收方式（设计目标，非已达到）'],['强度与光谱','暗处至日光条件分档；参考光谱仪对比；检验饱和、增益切换与暖白／冷白／RGB 混光'],['角度与位置','转台检验角响应；眼镜位置参考探头与耳夹同步佩戴；按环境和姿态报告误差'],['数值误差','可先设独立验证集 >10 lx 时中位相对误差 ≤15%、P95 ≤30%；低照度用绝对误差。结果若不达标，缩小声称范围']],[97,414])
c.showPage()
chhead(5,'真正的智能灯闭环')
y=cp(735,'系统链路：耳夹 → BLE → 手机／常驻网关 → 局域网 Hue Bridge → 兼容灯具 → 房间光场 → 耳夹回测。Hue 官方开放控制接口，但可调能力取决于灯具型号；普通固定色温灯不能通过软件变成可调色温灯。[S9]')
y=table(y,[['步骤','控制逻辑'],['1. 校准房间','用户选择灯组，设舒适上限与晚间边界；在固定位置扫过少量亮度／色温组合，测量其影响'],['2. 确认数据有效','已佩戴、时间戳新鲜、未饱和，且是授权房间；不能仅凭蓝牙在线就判断用户在同一房间'],['3. 温和调整','按时间段目标、用户偏好和当前读数做小步调整；建议最短 30–60 秒一次并设死区，防止频繁明暗变化'],['4. 回测与退出','等待光场稳定后回测；手动改灯立即暂停自动控制；断联保持舒适默认状态'],['5. 不可达时说明','灯已到上限仍不足则告知，建议改变位置或获得室外光；不能显示虚假的“目标已完成”']],[98,413])
y=cp(y,'本轮并未实现 Hue API 集成。方案需按当前 API v2、用户授权与设备能力完成开发。手机后台持续运行可能受系统限制；可先用前台演示，后续通过常驻网关或明确的连接策略解决。')
y=sh(y,'控制光环境 ≠ 控制生理状态')
y=cp(y,'第一层可验证闭环是“测光—调灯—回测”。第二层是“目标光环境是否改善人的状态”，需要用户研究。不能仅用灯的亮度百分比或色温推算精确 mEDI，也不能仅凭一日暴露计算出真实褪黑素相位。')
y=cp(y,'“你只拿到了天空的 12%”没有可审计分母：需要地点、天气、户外参考、朝向和时间定义。本版取消这个指标，用有效佩戴时长、分时段暴露及明确参考目标代替。')
c.showPage()
chhead(6,'尺寸、电量、装配与成本边界')
y=table(735,[['项目','R01 设计值／说明'],['电子舱','26.0 高 × 16.0 宽 × 10.4 厚 mm'],['含耳夹总包络','名义约 27.65 高 × 16.0 宽 × 17.7 厚 mm；不是微型耳钉'],['夹持','未加载软垫间隙 5.0 mm；夹片 0.5 mm；夹力、耳厚范围和疲劳寿命未验证'],['结构','壳壁名义 0.8 mm；PCB 13.4 × 23.4 × 0.6 mm；粘接与加工公差待定'],['充电','背面双触点：间距 6 mm，直径 1.4 mm；取下后在防反接底座充电；底座 CAD 未包含'],['质量','设计目标单只 ≤6 g；需完整 BOM 和样机称重，不把 CAD 空间模型当成实测质量']],[108,403])
y=sh(y,'续航只给可审计的预算，不给承诺')
y=cp(y,'以候选 74 mAh 电池、可用容量按 70% 估计，得到约 51.8 mAh。若全机电池端平均电流为 0.3／0.6／1.0 mA，计算续航约 173／86／52 小时。这里的平均电流是情景假设，包含稳压损耗、BLE、采样与储存；不是器件测试结果。')
y=cp(y,'建议先用 1–5 秒级采样与批量蓝牙传输做实验，按亮度动态调整增益；避免把光谱全通道高速常开。记录原始通道、增益、积分时间、佩戴置信度和本地时间偏移，以便校准及旅行时区处理。')
y=cp(y,'不能用“一颗传感器 £9”估算整机成本。报价要涵盖 PCB／贴装、光学扩散片、匹配电路、保护与充电、外壳夹具、软垫、装配校准、良率、底座与测试。现阶段未获得供应商报价，故不提供虚假的精确 BOM 总价。')
c.showPage()
chhead(7,'对商业分析的必要修正')
y=table(735,[['原分析说法','本次可支持的结论'],['“光是唯一杠杆”','不准确。CDC 同时讨论光照时机、睡眠安排及褪黑素等管理方式。[S10] 本产品可专注于光，但不能排除其他因素。'],['“耳位 = 眼位”','不成立。必须验证方位、头部遮挡、头发与姿态；只能先称近眼区域的佩戴位置测量。'],['“估值差来自闭环”','用两家公司融资额／估值与用户数对比，不能证明因果；融资额也不等于估值。本包不采用那些市场数字。'],['“别人都没做出来”','未完成专利、产品和学术全景检索，不能宣称全球首个或没有竞品。'],['“测到缺光就晚上补”','不应这样控制。分时段目标优先，晚间保护边界不能被累计不足覆盖。'],['“几周可做”','开发板演示可能很快；耳夹小型化、光学校准和佩戴验证是另一阶段，不能混用时间表。']],[140,371])
y=sh(y,'本版最有说服力的申请重点')
y=cp(y,'我们已有一个可编辑的空间设计与清楚的验证路线：先在固定办公位证明测量和调灯闭环，再决定耳夹形式是否足够稳定、舒适；用实验数据决定是否扩展到日常节律与旅行场景。申请资金购买的是下一阶段验证能力，而不是已经被证明的健康效果。')
c.showPage()
chhead(8,'从申请稿到功能样机的关卡')
y=table(735,[['关卡','交付与通过条件'],['G0 / 本次完成','25 个有效实体；零名义正体积干涉；STEP 导出回读；5 页结构审阅图、二维 DXF、零件清单和参数源码。'],['G1 / 桌面光学','开发板＋扩散窗口样件，与参考仪器对照；识别不同光源、角度与亮度下的误差。未过关先改光学。'],['G2 / 佩戴验证','无电外形样件；不同耳形、头发、眼镜与头部运动；检查固定方向、压力、滑落与舒适度。'],['G3 / 工程样机','电路原理图、可布线 PCB、固件、充电底座；实测耗电、发热、BLE 性能和读数稳定性。'],['G4 / 环境闭环','固定房间完成调灯、回测、手动覆盖、断网与遮挡场景；日志证明控制不是单向发送命令。'],['G5 / 效果研究','预先定义工作舒适度、依从性或时差相关终点与对照；先证明可测，再研究有效。']],[111,400])
y=cp(y,'R01 的关键未决问题：耳夹能否稳定朝向；5 mm 夹隙与夹力是否覆盖目标耳形；电池焊片和保护件是否放得下；PCB 天线在头部旁是否可用；扩散片是否维持低照度灵敏度与可接受角响应。')
y=cp(y,'进入制造前需由工程团队完成公差链、夹片疲劳、粘接／密封、防汗腐蚀、皮肤接触材料、射频与电池安全测试。当前无防水等级、认证或量产结论。STL 仅适合非通电外形验证；不要把普通打印材料直接视为适合长期皮肤接触。')
y=cp(y,'交付中的 STEP 和 Python 源码可供机械工程师继续编辑。电子图是器件布局预留，不是原理图或 Gerber；图纸上的零件也不等于供应商已经批准的器件库。')
c.showPage()
chhead(9,'一手来源与核查范围')
sources=[
('S1','ams OSRAM AS7341 原厂数据表：封装、通道和扩散片要求。','https://look.ams-osram.com/m/24266a3e584de4db/original/AS7341-DS000504.pdf'),
('S2','Nordic nRF52832 mechanical specifications / ordering information。','https://docs.nordicsemi.com/r/bundle/ps_nrf52832/page/mec_spec.html'),
('S3','TI BQ25120A 产品与数据表：封装、电源及充电功能。','https://www.ti.com/product/BQ25120A'),
('S4','ST LIS2DW12 原厂产品资料。','https://www.st.com/en/mems-and-sensors/lis2dw12.html'),
('S5','VARTA Product Overview：CP1254 A4X 名义尺寸、容量。','https://www.varta-ag.com/fileadmin/varta/industry/downloads/products/FOLDER_Product_Overview_en_web.pdf'),
('S6','de Vries et al., 2026：佩戴位置、方向与身体遮挡。','https://doi.org/10.1038/s44323-026-00079-z'),
('S7','CIE PS 001:2024，Proper Light at the Proper Time；指标框架参考 CIE S 026。','https://cie.co.at/publications/cie-position-statement-integrative-lighting-recommending-proper-light-proper-time-3rd'),
('S8','Cochrane, 2023：蓝光过滤镜片与视觉疲劳的系统评价。','https://doi.org/10.1002/14651858.CD013244.pub2'),
('S9','Philips Hue 官方开发者资料，API v2 与灯具控制能力。','https://developers.meethue.com/new-hue-api/'),
('S10','CDC Yellow Book：Jet Lag Disorder。','https://www.cdc.gov/yellow-book/hcp/travel-air-sea/jet-lag-disorder.html'),
('S11','ams OSRAM AS7343 原厂产品页：备选多通道光谱器件。','https://ams-osram.com/products/sensor-solutions/ambient-light-color-spectral-proximity-sensors/ams-as7343-spectral-sensor')]
y=737
for no,desc,url in sources:
 y=para(42,y,f'{no}　{desc}',W-84,9,14,'CN')-3
 short=url if len(url)<105 else url[:100]+'...'
 yy=y-9;txt(42,yy,short,7,'Helvetica',GRAY);c.linkURL(url,(42,yy-1,W-42,yy+9),relative=0);y=yy-17
cp(y,'核查日期：2026-09-27。来源用于确认器件与技术边界；本包没有核实原商业分析中的融资额、估值、用户数、YC 截止日或“世界首个”主张。')
c.save()
# Store source index as editable text, no copied source documents
(ROOT/'Engineering/Sources.md').write_text('# Sources / accessed 2026-09-27\n\n'+'\n\n'.join(f'## {no}\n{desc}\n{url}' for no,desc,url in sources))
print('Created 5-page CAD review and 9-page Chinese brief')
