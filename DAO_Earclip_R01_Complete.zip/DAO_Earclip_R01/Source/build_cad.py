"""DAO R01 concept spatial CAD. Units mm. Not production released.
Run with CadQuery 2.7, numpy, matplotlib, ezdxf. No electrical routing implied.
"""
from pathlib import Path
import cadquery as cq, numpy as np, json, csv, math
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
from matplotlib.colors import to_rgb
import ezdxf
ROOT=Path(__file__).resolve().parents[1]
P={'pod_width':16.,'pod_height':26.,'pod_depth':10.4,'corner_radius':4.,'wall':.8,'split_z':8.8,'pcb_width':13.4,'pcb_height':23.4,'pcb_z':6.9,'pcb_thickness':.6,'cell_diameter_envelope':12.4,'cell_height_envelope':5.7,'cell_y':-4.,'window_diameter':5.,'window_y':3.,'nominal_pad_gap':5.0}
(ROOT/'Engineering/parameters.json').write_text(json.dumps(P,indent=2))
def rr(w,h,d,r,z=0):
 return cq.Workplane('XY').rect(w,h).extrude(d).edges('|Z').fillet(r).translate((0,0,z))
def box(w,h,d,x,y,z): return cq.Workplane('XY').box(w,h,d,centered=(True,True,False)).translate((x,y,z))
def cyl(r,h,x,y,z): return cq.Workplane('XY').circle(r).extrude(h).translate((x,y,z))
parts={}; meta=[]
def add(k,s,c,desc,mat,role='modeled',explode=0):
 s=s.val() if isinstance(s,cq.Workplane) else s
 if not s.isValid(): raise ValueError('Invalid '+k)
 parts[k]=(s,c,explode)
 b=s.BoundingBox();meta.append({'id':k,'description':desc,'material_or_candidate':mat,'status':role,'bbox_mm':[round(b.xlen,3),round(b.ylen,3),round(b.zlen,3)],'volume_mm3':round(s.Volume(),3)})
# Main rear tub, optical cap and separate assembly seam.
outer=rr(16,26,8.8,4)
inner=rr(14.4,24.4,8.1,3.2,.8)
rear=outer.cut(inner)
for x in (-6.85,6.85):rear=rear.union(box(.7,12,.4,x,0,6.5))
# through shell charge feedthroughs, lower rear surface, not in skin pad area
for x in (-3,3):rear=rear.cut(cyl(.85,.9,x,-9.5,-.05))
add('01_rear_housing',rear,'#cbb681','Rear tub / nonconductive champagne finish','PC or PA12 prototype',explode=0)
cap=rr(16,26,1.5,4,8.9).cut(rr(14.4,24.4,.7,3.2,8.85)).cut(cyl(2.6,2,0,3,8.7))
add('02_front_cap',cap,'#e1d4b5','Optical front cap / RF-transparent crown','PC, nonmetallic pigment',explode=28)
# adhesive bond gap, deliberately separate from housing solids
gasket=rr(16,26,.1,4,8.8).cut(rr(14.4,24.4,.12,3.2,8.79))
add('03_bond_seam',gasket,'#777d75','Bond-line geometry, process TBD','Adhesive concept',explode=23)
# Optical diffuser disk and surrounding adhesive annulus
add('04_optical_diffuser',cyl(2.5,.5,0,3,9.9),'#b6d9d5','Achromatic diffuser / flush entrance aperture','Optical diffuser grade TBD',explode=36)
add('05_window_bond',cyl(2.6,.5,0,3,9.9).cut(cyl(2.5,.6,0,3,9.85)),'#71857f','Window bond annulus','Optically stable adhesive TBD',explode=36)
# Baffle supports to PCB; external ring seats below cap; 0.8 mm gap over sensor top
baffle=cyl(2.55,1.6,0,3,7.9).cut(cyl(2.2,1.8,0,3,7.8))
add('06_optical_baffle',baffle,'#293b39','Black light well, opening 4.4 mm','Black polymer',explode=18)
board=rr(13.4,23.4,.6,2.3,6.9)
add('07_main_pcb',board,'#225b50','Custom PCB envelope; routing not designed','FR4 0.60 mm nominal',role='placement envelope',explode=12)
add('08_AS7341',box(3.1,2,1,0,3,7.5),'#263c43','Spectral light sensor','ams OSRAM AS7341',role='package envelope',explode=12)
add('09_BLE_SoC',box(3,3.3,.45,0,-2.2,7.5),'#2d3540','BLE controller incl. rounded-up package clearance','Nordic nRF52832 WLCSP candidate',role='package envelope',explode=12)
add('10_charge_PMIC',box(2.5,2.5,.65,-3.2,-7,7.5),'#364149','Charger + 1.8 V power rail','TI BQ25120A candidate',role='package envelope',explode=12)
add('11_accelerometer',box(2,2,.7,3.1,-7,7.5),'#40464a','Motion / tilt, not gaze direction','ST LIS2DW12',role='package envelope',explode=12)
# Integration allowances: passives, external flash, electrode frontend, battery protection
for k,x,y,w,h,d in [('12_flash',-4,0,2.5,3,.7),('13_wear_frontend',4,0,2.5,3,.7),('14_power_protection',0,-9.7,4,1.5,.7),('15_RF_matching',-3,6.3,3.5,1.5,.65),('16_crystal',3.5,5.8,2.5,2,.65)]:
 add(k,box(w,h,d,x,y,7.5),'#536260',k.split('_',1)[1]+' allocation','Unselected parts / space allocation',role='allocation only',explode=12)
add('17_RF_allocation',box(10,3.2,.12,0,9.3,7.5),'#b89b53','Antenna region; NOT a tuned antenna','Copper geometry intentionally unspecified',role='allocation only',explode=12)
add('18_cell_envelope',cyl(6.2,5.7,0,-4,1.0),'#94a8ae','Cell clearance envelope, not exact battery body','VARTA CP1254 A4X candidate: nominal 12.1 x 5.4',role='clearance envelope',explode=6)
add('19_cell_insulator',cyl(6.35,.15,0,-4,.8),'#555e59','Cell bottom insulator','Dielectric film',explode=4)
add('24_wear_electrode',cyl(2,.05,0,5,.82),'#b89b53','Capacitive wear electrode; sensing through rear shell/pad','Copper foil, routing TBD',role='allocation only',explode=1)
# rear pad is separate, no clamp-force claim
add('20_skin_pad',rr(7,8,.8,2,-.8).translate((0,2,0)),'#8d9f91','Housing-side soft skin pad','Skin-contact silicone TBD',explode=-3)
# U shaped sheet bracket in YZ, open above (positive y). 0.5 mm nominal sheet.
ring=cq.Workplane('YZ').center(-11,-3.65).circle(3.65).circle(3.15).extrude(2,both=True)
left=box(5,10,12,0,-16,-10)
curve=ring.intersect(left)
front=box(4,5,.5,0,-8.5,-.5)
back=box(4,14,.5,0,-4,-7.3)
clip=curve.union(front).union(back)
add('21_spring_clip',clip,'#ae9567','Spring clip, unqualified force and retention','Titanium sheet candidate 0.5 mm',role='mechanical concept',explode=-9)
add('22_rear_pad',rr(7,8,1,2,-6.8).translate((0,-1,0)),'#8d9f91','Opposing comfort pad; replaceable shim concept','Skin-contact silicone TBD',explode=-9)
for i,x in enumerate((-3,3)):
 add(f'23_charge_contact_{i+1}',cyl(.7,.7,x,-9.5,0),'#c8aa62','Sealed charging feedthrough','Gold plated contact, seal TBD',role='contact envelope',explode=0)
# All part and assembly exports
assembly=cq.Assembly(name='DAO_R01_CONCEPT')
for k,(s,c,e) in parts.items():
 assembly.add(s,name=k,color=cq.Color(*to_rgb(c)))
 cq.exporters.export(s,str(ROOT/'CAD'/f'{k}.step'))
 if k in ['01_rear_housing','02_front_cap','20_skin_pad','21_spring_clip','22_rear_pad']:
  cq.exporters.export(s,str(ROOT/'CAD'/f'{k}.stl'),tolerance=.03,angularTolerance=.12)
assembly.save(str(ROOT/'CAD/DAO_R01_Assembly.step'))
exp=cq.Assembly(name='DAO_R01_EXPLODED')
for k,(s,c,e) in parts.items():exp.add(s.translate((0,0,e)),name=k,color=cq.Color(*to_rgb(c)))
exp.save(str(ROOT/'CAD/DAO_R01_Exploded.step'))
compound=cq.Compound.makeCompound([v[0] for v in parts.values()])
# Actual nominal geometry collision inspection. Allocations are volumetric but not circuit proof.
collisions=[]
keys=list(parts)
for i,a in enumerate(keys):
 for b in keys[i+1:]:
  vol=parts[a][0].intersect(parts[b][0]).Volume()
  if vol>1e-5:collisions.append({'a':a,'b':b,'intersection_mm3':round(vol,6)})
report={'valid_solids':all(s.isValid() for s,c,e in parts.values()),'part_count':len(parts),'interferences':collisions,'assembly_bbox_mm':[round(v,3) for v in [compound.BoundingBox().xlen,compound.BoundingBox().ylen,compound.BoundingBox().zlen]],'limitations':['No PCB routing or electrical validation','No clamp force/skin pressure simulation','No optical calibration, RF simulation or tolerance stack approval','Component representations are simplified package/clearance envelopes']}
(ROOT/'Engineering/geometry_validation.json').write_text(json.dumps(report,indent=2))
(ROOT/'Engineering/parts_manifest.json').write_text(json.dumps(meta,indent=2))
with open(ROOT/'Engineering/BOM_Concept.csv','w') as f:
 w=csv.writer(f);w.writerow(['ID','Description','Candidate/material','Model status','Bounding box mm','Volume mm3'])
 for r in meta:w.writerow([r['id'],r['description'],r['material_or_candidate'],r['status'],r['bbox_mm'],r['volume_mm3']])
# Render meshes computed from the real BREP, never generated artwork.
mesh={}
for k,(s,c,e) in parts.items():
 verts,faces=s.tessellate(.07,.16);arr=np.array([[v.x,v.y,v.z] for v in verts]);mesh[k]=(arr,np.array(faces),c,e)
def render(name,selected=None,exploded=False,elev=24,azim=-58):
 from PIL import Image
 ev,az=np.radians([elev,azim]);d=np.array([np.cos(ev)*np.cos(az),np.cos(ev)*np.sin(az),np.sin(ev)])
 u=np.array([-np.sin(az),np.cos(az),0]);v=np.cross(d,u);M=np.stack([u,v,d],axis=1)
 triangles=[];colors=[]
 for k,(verts,faces,c,e) in mesh.items():
  if selected and k not in selected:continue
  vv=verts.copy();vv[:,2]+=e if exploded else 0
  pp=vv[faces];normal=np.cross(pp[:,1]-pp[:,0],pp[:,2]-pp[:,0]);normal/=np.maximum(np.linalg.norm(normal,axis=1)[:,None],1e-10)
  # Two-sided neutral technical shading; winding-independent.
  light=np.array([-.35,-.4,.84]);shade=.67+.33*np.abs(normal@light)
  colors.extend(np.clip(np.array(to_rgb(c))[None,:]*shade[:,None]*255,0,255).astype('uint8'))
  triangles.extend((vv@M)[faces])
 tri=np.array(triangles);cc=np.array(colors);N=1800;xy=tri[:,:,:2];lo=xy.min(axis=(0,1));hi=xy.max(axis=(0,1));center=(lo+hi)/2;scale=N*.82/max(hi-lo)
 tri[:,:,0]=(tri[:,:,0]-center[0])*scale+N/2;tri[:,:,1]=N/2-(tri[:,:,1]-center[1])*scale
 bg=np.array([244,243,237],dtype='uint8');im=np.tile(bg,(N,N,1));depth=np.full((N,N),-np.inf,dtype='float32')
 for t,col in zip(tri,cc):
  xmin=max(0,int(np.floor(t[:,0].min())));xmax=min(N-1,int(np.ceil(t[:,0].max())));ymin=max(0,int(np.floor(t[:,1].min())));ymax=min(N-1,int(np.ceil(t[:,1].max())))
  if xmax<xmin or ymax<ymin:continue
  a,b,c0=t;den=(b[1]-c0[1])*(a[0]-c0[0])+(c0[0]-b[0])*(a[1]-c0[1])
  if abs(den)<1e-9:continue
  xx=np.arange(xmin,xmax+1)[None,:]+.5;yy=np.arange(ymin,ymax+1)[:,None]+.5
  w0=((b[1]-c0[1])*(xx-c0[0])+(c0[0]-b[0])*(yy-c0[1]))/den
  w1=((c0[1]-a[1])*(xx-c0[0])+(a[0]-c0[0])*(yy-c0[1]))/den;w2=1-w0-w1
  zz=w0*a[2]+w1*b[2]+w2*c0[2];dep=depth[ymin:ymax+1,xmin:xmax+1]
  mask=(w0>=-1e-6)&(w1>=-1e-6)&(w2>=-1e-6)&(zz>dep)
  dep[mask]=zz[mask];im[ymin:ymax+1,xmin:xmax+1][mask]=col
 Image.fromarray(im).resize((1600,1600),Image.Resampling.LANCZOS).save(ROOT/'Preview'/name)
render('DAO_R01_Assembly.png')
render('DAO_R01_Rear.png',elev=-24,azim=-48)
render('DAO_R01_Exploded.png',exploded=True,elev=19,azim=-58)
render('DAO_R01_Internal.png',selected=[k for k in parts if k not in ['02_front_cap','03_bond_seam','04_optical_diffuser','05_window_bond']],elev=48,azim=-75)
# Exact vector outlines and dimensions in DXF model space; all units mm.
doc=ezdxf.new('R2010');doc.units=4;m=doc.modelspace()
for n,col in [('OUTLINE',7),('HIDDEN',8),('DIMENSIONS',3),('TEXT',7),('OPTICS',4),('ELECTRONICS',6)]:doc.layers.new(n,dxfattribs={'color':col})
def poly(points,layer='OUTLINE',close=False):m.add_lwpolyline(points,close=close,dxfattribs={'layer':layer})
def roundpts(w,h,r,off=(0,0)):
 pts=[]
 for cx,cy,start in [(w/2-r,h/2-r,0),(-w/2+r,h/2-r,90),(-w/2+r,-h/2+r,180),(w/2-r,-h/2+r,270)]:
  for a in np.linspace(start,start+90,33):pts.append((off[0]+cx+r*np.cos(np.radians(a)),off[1]+cy+r*np.sin(np.radians(a))))
 return pts
poly(roundpts(16,26,4),close=True);m.add_circle((0,3),2.5,dxfattribs={'layer':'OPTICS'})
m.add_text('FRONT / optical face',dxfattribs={'height':1.4,'insert':(-8,17),'layer':'TEXT'})
# Side elevation shown as outer bounding profile plus true clip outline sampled via CAD edges
for k in ['01_rear_housing','02_front_cap','21_spring_clip','20_skin_pad','22_rear_pad']:
 for edge in parts[k][0].Edges():
  try:
   pts=[edge.positionAt(float(t)) for t in np.linspace(0,1,50)]
   poly([(v.z+40,v.y) for v in pts])
  except Exception:pass
m.add_text('SIDE / Y-Z',dxfattribs={'height':1.4,'insert':(31,17),'layer':'TEXT'})
poly(roundpts(13.4,23.4,2.3,(75,0)),layer='ELECTRONICS',close=True)
for k in ['08_AS7341','09_BLE_SoC','10_charge_PMIC','11_accelerometer','17_RF_allocation']:
 b=parts[k][0].BoundingBox();poly([(75+b.xmin,b.ymin),(75+b.xmax,b.ymin),(75+b.xmax,b.ymax),(75+b.xmin,b.ymax)],'ELECTRONICS',True)
m.add_text('PCB / envelopes only',dxfattribs={'height':1.4,'insert':(66,17),'layer':'TEXT'})
for p1,p2,base,ang in [((-8,-13),(8,-13),(0,-18),0),((-8,-13),(-8,13),(-14,0),90),((40,13),(50.4,13),(45,18),0),((68.3,-11.7),(81.7,-11.7),(75,-18),0)]:
 d=m.add_linear_dim(base=base,p1=p1,p2=p2,angle=ang,dimstyle='EZDXF',override={'dimtxt':1.1,'dimasz':.6});d.render()
m.add_text('DAO R01 | CONCEPT / NOT FOR PRODUCTION | mm | 2026-09-27',dxfattribs={'height':1.4,'insert':(-14,-24),'layer':'TEXT'})
doc.saveas(ROOT/'Drawings/DAO_R01_2D_Layouts.dxf')
# round trip confirms usable STEP geometry
loaded=cq.importers.importStep(str(ROOT/'CAD/DAO_R01_Assembly.step'))
report['step_roundtrip_valid']=loaded.val().isValid();report['step_roundtrip_solids']=len(loaded.solids().vals())
(ROOT/'Engineering/geometry_validation.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
