# Sources / accessed 2026-09-27

## S1
ams OSRAM AS7341 原厂数据表：封装、通道和扩散片要求。
https://look.ams-osram.com/m/24266a3e584de4db/original/AS7341-DS000504.pdf

## S2
Nordic nRF52832 mechanical specifications / ordering information。
https://docs.nordicsemi.com/r/bundle/ps_nrf52832/page/mec_spec.html

## S3
TI BQ25120A 产品与数据表：封装、电源及充电功能。
https://www.ti.com/product/BQ25120A

## S4
ST LIS2DW12 原厂产品资料。
https://www.st.com/en/mems-and-sensors/lis2dw12.html

## S5
VARTA Product Overview：CP1254 A4X 名义尺寸、容量。
https://www.varta-ag.com/fileadmin/varta/industry/downloads/products/FOLDER_Product_Overview_en_web.pdf

## S6
de Vries et al., 2026：佩戴位置、方向与身体遮挡。
https://doi.org/10.1038/s44323-026-00079-z

## S7
CIE PS 001:2024，Proper Light at the Proper Time；指标框架参考 CIE S 026。
https://cie.co.at/publications/cie-position-statement-integrative-lighting-recommending-proper-light-proper-time-3rd

## S8
Cochrane, 2023：蓝光过滤镜片与视觉疲劳的系统评价。
https://doi.org/10.1002/14651858.CD013244.pub2

## S9
Philips Hue 官方开发者资料，API v2 与灯具控制能力。
https://developers.meethue.com/new-hue-api/

## S10
CDC Yellow Book：Jet Lag Disorder。
https://www.cdc.gov/yellow-book/hcp/travel-air-sea/jet-lag-disorder.html

## S11
ams OSRAM AS7343 原厂产品页：备选多通道光谱器件。
https://ams-osram.com/products/sensor-solutions/ambient-light-color-spectral-proximity-sensors/ams-as7343-spectral-sensor